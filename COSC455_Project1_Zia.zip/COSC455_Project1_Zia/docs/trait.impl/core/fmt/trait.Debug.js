(function() {
    const implementors = Object.fromEntries([["lolcompiler",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.98.1/core/fmt/trait.Debug.html\" title=\"trait core::fmt::Debug\">Debug</a> for <a class=\"struct\" href=\"lolcompiler/ast/struct.Document.html\" title=\"struct lolcompiler::ast::Document\">Document</a>",0],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.98.1/core/fmt/trait.Debug.html\" title=\"trait core::fmt::Debug\">Debug</a> for <a class=\"enum\" href=\"lolcompiler/ast/enum.Node.html\" title=\"enum lolcompiler::ast::Node\">Node</a>",0]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":59,"fragment_lengths":[535]}